// parametri za konekciju sa bazom podataka
//koristenje username i password

const DATABASECONNECTION =
  "mongodb://amujkic:amujkic837@ds255728.mlab.com:55728/amujkic-namjestaj";

//povlacenje podataka iz baze
module.exports = {
  DATABASECONNECTION,
};
