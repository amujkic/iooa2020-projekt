var express = require("express");
var router = express.Router();

// TODO:: add in error and info

router.use(function (req, res, next) {
  res.locals.currentUser = req.user;
  next();
});

router.use("/", require("./home"));
router.use("/", require("./namjestaj"));
router.use("/", require("./narudzba"));

module.exports = router;
